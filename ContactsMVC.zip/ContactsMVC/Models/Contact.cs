﻿using System;

namespace ContactsMVC.Models
{
    public class Contact
    {
        // Primary key, actually an email
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Password { get; set; }
        public string Category { get; set; }
        public string Subcategory { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime BirthdayDate { get; set; }

        // Class constructor
        public Contact()
        {

        }

    }
}
